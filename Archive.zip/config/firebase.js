// config/firebase.js
const admin = require('firebase-admin');
const serviceAccount = require('../config/bikestore-key.json'); // Adjust path as needed

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // You can add other configuration options here if needed
});

module.exports = admin;
