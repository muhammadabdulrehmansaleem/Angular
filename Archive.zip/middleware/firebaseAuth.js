// middleware/firebaseAuth.js
const admin = require('../config/firebase'); // Import the initialized Firebase Admin SDK

module.exports = async (req, res, next) => {
  // Extract the token from the Authorization header
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ msg: 'No token, authorization denied' });
  }

  try {
    // Verify the token using Firebase Admin SDK
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = decodedToken; // Attach user info to the request object
    next(); // Proceed to the next middleware or route handler
  } catch (err) {
    // Handle invalid or expired token
    res.status(401).json({ msg: 'Token is not valid' });
  }
};
