// routes/profile.js
const express = require('express');
const router = express.Router();
const firebaseAuth = require('../middleware/firebaseAuth'); // Import the middleware

// Profile route (protected)
router.get('/profile', firebaseAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user.uid).select('-password');
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;
