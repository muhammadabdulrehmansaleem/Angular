import { Injectable } from '@angular/core';
import { Auth, createUserWithEmailAndPassword, getIdToken, GoogleAuthProvider, signInWithPopup } from '@angular/fire/auth';
import { HttpClient } from '@angular/common/http';
import { User } from './Models/user';
import { getAuth } from '@angular/fire/auth';
import { catchError, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:5001/api/auth'; 
  constructor(private auth: Auth, private http: HttpClient) {}
  signUp(user: User): Observable<any> {
    return new Observable(observer => {
      try {
        if (!user.password) {
          throw new Error('Password is required for sign-up');
        }
        createUserWithEmailAndPassword(this.auth, user.email, user.password).then(userCredential => {
          console.log("here")
          return getIdToken(userCredential.user);
        }).then(idToken => {
          return this.http.post(`${this.apiUrl}/register`, { ...user, idToken }).toPromise();
        }).then(result => {
          observer.next(result);
          observer.complete();
        }).catch(error => {
          observer.error(error);
        });
      } catch (error) {
        observer.error(error);
      }
    }).pipe(
      catchError(error => {
        console.error('Sign-up error:', error);
        throw error;
      })
    );
  }

  async googleSignIn() {
    try {
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(this.auth, provider);
      const idToken = await getIdToken(userCredential.user);
      return this.http.post(`${this.apiUrl}/google-signin`, { idToken }).toPromise();
    } catch (error) {
      console.error('Google sign-in error:', error);
      throw error;
    }
  }
}
