import { Component, EventEmitter, Input, Output ,NgModule} from '@angular/core';
import { CommonModule, NgSwitchCase, NgSwitchDefault, NgSwitch } from '@angular/common';
import { FormsModule ,FormBuilder} from '@angular/forms';
import { RouterModule, RouterOutlet } from '@angular/router';
import { User } from '../../Models/user';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterOutlet, RouterModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  userModel=new User("","");
  confirmPassword:string="";
  isMatched:boolean=true
  isLengthValid: boolean = false;
  isAlphaNumericValid: boolean = false;
  constructor(private authService: AuthService,private http: HttpClient) {}
  async onSubmit() {
  console.log(this.userModel)
  try {
    const response = await this.authService.signUp(this.userModel);
    console.log('Registration successful', response);
  } catch (error) {
    console.error('Registration error', error);
  }

}
checkPasswordValidity() {
  if (this.userModel.password) {
    this.isLengthValid = this.userModel.password.length >= 8;
    this.isAlphaNumericValid = /[A-Za-z]/.test(this.userModel.password) && /\d/.test(this.userModel.password);
  } else {
    // Reset validity if password is undefined
    this.isLengthValid = false;
    this.isAlphaNumericValid = false;
  }
}

confirmPasswordFun(){
  if(this.confirmPassword==this.userModel.password){
    this.isMatched=true;
  }
  else{
    this.isMatched=false;
  }
}
googleSignIn(){}
registerForm: any;

}
