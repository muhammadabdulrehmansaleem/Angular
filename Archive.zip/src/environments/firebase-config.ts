// src/environments/firebase-config.ts
export const firebaseConfig = {
    apiKey: "AIzaSyBTC_2bFA6gFYLl2tUWzdEw6paxXBe4oY4",
  authDomain: "bikestore-1be24.firebaseapp.com",
  projectId: "bikestore-1be24",
  storageBucket: "bikestore-1be24.appspot.com",
  messagingSenderId: "166157322072",
  appId: "1:166157322072:web:e1126e64dd8c95e241072d",
  measurementId: "G-BMK4HCMF6B"
  };
  