import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth.service';
import { HttpClientModule } from '@angular/common/http';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'client';
  email: string = '';
  constructor(private authService: AuthService) {}
  async signInWithGoogle() {
    await this.authService.signInWithGoogle();
  }
  async resetPassword() {
    if (this.email) {
      await this.authService.resetPassword(this.email);
    }
  }
}
