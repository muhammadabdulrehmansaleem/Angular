import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Auth, GoogleAuthProvider, signInWithPopup, sendPasswordResetEmail } from '@angular/fire/auth';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs/internal/Observable';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  [x: string]: any;
  private apiUrl="http://localhost:3000";
  constructor(private auth: Auth, private http: HttpClient) { }
  async signInWithGoogle(): Promise<void> {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(this.auth, provider);
      const user = result.user;
      const idToken = await user.getIdToken();
      console.log(idToken)
      // Send ID token to backend
      await this.http.post(`${this.apiUrl}/auth/google-signin`, { idToken }).toPromise();
      console.log('User signed in and ID token sent to backend:', user);
    } catch (error) {
      console.error('Error during sign-in:', error);
    }
  }
  async resetPassword(email: string): Promise<void> {
    try {
      await this.http.post(`${this.apiUrl}/auth/reset-password`, { email }).toPromise();
      console.log('Password reset email sent.');
    } catch (error) {
      console.error('Error sending password reset email:', error);
    }
  }  
  signup(user: { name: string; email: string; password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/signup`, user)
      .pipe(
        catchError(this.handleError)
      );
  }
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }

}
