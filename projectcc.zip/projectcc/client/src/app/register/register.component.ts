import { Component, EventEmitter, Input, Output ,NgModule} from '@angular/core';
import { CommonModule, NgSwitchCase, NgSwitchDefault, NgSwitch } from '@angular/common';
import { FormsModule ,FormBuilder} from '@angular/forms';
import { RouterModule, RouterOutlet } from '@angular/router';
import { AuthService } from '../auth.service';
import { catchError, of } from 'rxjs';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterOutlet, RouterModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  name:string="";
  email:string="";
  password:string="";
  errorMessage: string | null = null;

  constructor(private authService: AuthService) {}

checkPasswordValidity() {
  if (this.password) {
    this.isLengthValid = this.password.length >= 8;
    this.isAlphaNumericValid = /[A-Za-z]/.test(this.password) && /\d/.test(this.password);
  } else {
    // Reset validity if password is undefined
    this.isLengthValid = false;
    this.isAlphaNumericValid = false;
  }
}
confirmPasswordFun(){
  if(this.confirmPassword==this.password){
    this.isMatched=true;
  }
  else{
    this.isMatched=false;
  }
}
userModel: any;
onSubmit() {
  const userData = {
    email: this.email,
    name: this.name,
    password: this.password
  };
  console.log(userData);
  this.authService.signup(userData).pipe(
    catchError(error => {
      this.errorMessage = error;
      return of(null); // Return an empty observable to complete the stream
    })
  )
  .subscribe(response => {
    if (response) {
      // Handle successful signup response
      console.log('Signup successful:', response);
    }
  });
}
async signInWithGoogle() {
  await this.authService.signInWithGoogle();
}
  confirmPassword:string="";
  isMatched:boolean=true
  isLengthValid: boolean = false;
  isAlphaNumericValid: boolean = false;
}
