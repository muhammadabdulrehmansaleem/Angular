// config/firebaseConfig.js
const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json'); // Path to your service account key

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://bikestore-1be24-default-rtdb.firebaseio.com/" // Replace with your actual database URL
});

// Export the initialized admin instance
module.exports = admin;
