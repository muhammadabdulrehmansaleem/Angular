const admin = require('../config/firebaseConfig')
const axios = require('axios');
const User = require('../models/User')
const firebaseConfig = require('../config/serviceAccountKey.json')
const authService = require('../services/authService');
const { refreshToken } = require('firebase-admin/app');
const {sendResetPasswordEmail}=require('../services/emailService')
const FIREBASE_API_KEY = firebaseConfig.api_key;


const googleSignIn = async (req, res) => {
  const { idToken } = req.body;
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userRecord = await admin.auth().getUser(decodedToken.uid);
    console.log("here")
    // Save or update user in the database
    const user = await User.findOneAndUpdate(
      { uid: userRecord.uid },
      {
        email: userRecord.email,
        name: userRecord.displayName,
      },
      { upsert: true, new: true }
    );

    res.status(200).json({ user });
  } catch (error) {
    console.log("Error: ", error);
    res.status(400).json({ error: error.message });
  }
};

const resetPassword = async (req, res) => {
  const { email } = req.body;
  try {
    const response = await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${FIREBASE_API_KEY}`, {
      requestType: 'PASSWORD_RESET',
      email: email,
    });
    res.status(200).json({ message: 'Password reset email sent.', response: response.data });
  } catch (error) {
    res.status(400).json({ error: error.response.data.error.message });
  }
};
const login = async (req, res) => {
  const {email,password}=req.body;
  try{
    const {accessToken,refreshToken}=await authService.login(email,password);
    res.status(200).json({accessToken,refreshToken});
  }
  catch(error)
  {
    res.status(400).json({error:error.message});
  }
};

const signup = async (req, res) => {
  const { email, password, name} = req.body;
  console.log(req.body)
  try {
    const result = await authService.signup(email, password, name);
    res.status(201).json({
      message:'User Registered successfully',
      user:result.user,
      accessToken:result.accessToken,
      refreshToken:result.refreshToken
    });
  }catch(error){
    console.log(error);
    res.status(400).json({error:error.message});
  }

};
const refreshTokenHandler = async (req, res) => {
  const { refreshToken } = req.body;
  try {
      const { accessToken } = await authService.getAccessToken(refreshToken);
      res.status(200).json({ accessToken });
  } catch (error) {
      res.status(400).json({ error: error.message });
  }
};
const requestPasswordReset= async(req,res)=>{
  const {email}=req.body;
  try{
    const user=await User.findOne({email});
    if(!user){
      return res.status(404).json({error:'No user with this email found'});
    }
    const resetToken=user.generatePasswordResetToken();
    await user.save();
    
    await sendResetPasswordEmail(email,resetToken);

    res.status(200).json({message:'Password reset email sent'});
  }catch(error)
  {
    res.status(500).json({ error: error.message });
  }
}
const forgetPassword = async (req, res) => {
  const { token, newPassword } = req.body;

  try {
      const user = await User.findOne({
          resetPasswordToken: token,
          resetPasswordExpires: { $gt: Date.now() }
      });

      if (!user) {
          return res.status(400).json({ error: 'Password reset token is invalid or has expired' });
      }

      user.password = newPassword;
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;

      await user.save();

      res.status(200).json({ message: 'Password has been reset successfully' });
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};


module.exports = {
  googleSignIn,
  resetPassword,
  login,
  signup,
  refreshTokenHandler,
  requestPasswordReset,
  forgetPassword
};