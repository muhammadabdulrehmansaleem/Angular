const admin=require('../config/firebaseConfig')

const authMiddleware=async(req,res,next)=>{
    const idToken=req.headers.authorization?.split('Bearer ')[1];
    
    if(!idToken)
    {
        return res.status(401).json({message:"Unauthorized token not found"});
    }

    try{
        const decodeToken=await admin.auth().verifyIdToken(idToken);
        req.user=decodeToken;
        next();
    }
    catch(error){
        return res.status(401).json({message:"Unauthorized in decoding"});
    }
};
module.exports=authMiddleware;