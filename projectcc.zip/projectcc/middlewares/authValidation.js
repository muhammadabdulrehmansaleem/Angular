const authValidation=(req,res,next)=>{
    console.log('Auth validation middleware triggered');

    
    next();
}
module.exports=authValidation;