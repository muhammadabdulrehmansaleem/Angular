const mongoose=require('mongoose');
const bcrypt=require('bcryptjs')
const crypto = require('crypto');

const userSchema=new mongoose.Schema({
    uid:{type:String,required:false,unique:true},
    email:{type:String,required:true},
    name:{type:String},
    password:{type:String},
    resetPasswordToken: { type: String }, 
    resetPasswordExpires: { type: Date }
});
userSchema.pre('save',async function (next){
    if(!this.isModified('password')){
        return next();
    }
    try{
        const salt =await bcrypt.genSalt(10);
        this.password=await bcrypt.hash(this.password,salt);
        next();
    }catch(error)
    {
        next(error);
    }
});
userSchema.methods.comparePassword=async function(candidatePassword){
    return await bcrypt.compare(candidatePassword,this.password);
};

// Method to generate a reset token
userSchema.methods.generatePasswordResetToken = function () {
    const resetToken = crypto.randomBytes(20).toString('hex');

    this.resetPasswordToken = resetToken;
    this.resetPasswordExpires = Date.now() + 3600000; 
    
    return resetToken;
};

const User=mongoose.model('User',userSchema);
module.exports=User;