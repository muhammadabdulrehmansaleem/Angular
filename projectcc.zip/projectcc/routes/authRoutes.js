const express=require('express');
const admin=require('../config/firebaseConfig');
const authMiddleware=require('../middlewares/authMiddleware');
const User=require('../models/User');
const firebaseConfig=require('../config/serviceAccountKey.json');
FIREBASE_API_KEY=firebaseConfig.api_key;

const router=express.Router();

router.post('/google-signin',async(req,res)=>{
    const {idToken}=req.body;
    try{
        const decodedToken=await admin.auth().verifyIdToken(idToken);
        const userRecord=await admin.auth().getUser(decodedToken.uid);

        const user=await User.findByIdAndUpdate(
            {uid:userRecord.uid},
            {
                email:userRecord.email,
                name:userRecord.displayName,
            },
            {upsert:true,new:true}
        );
        res.status(200).json({user});
    }
    catch(error){
        res.status(400).json({error:error.message});
    }
}
);

router.post('/reset-password',async(req,res)=>{
    try{
        const response=await axios.post('https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${FIREBASE_API_KEY}',{
            requestType:'PASSWORD_RESET',
            email:email,
        });
        res.status(200).json({message:'Password Rest email sent.',response:response.data});
    }catch(error)
    {
        res.status(400).json({error:error.response.data.error.message});
    }
})
module.exports=router;