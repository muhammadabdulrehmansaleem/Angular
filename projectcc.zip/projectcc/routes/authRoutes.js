const express=require('express');
const admin=require('../config/firebaseConfig');
const authMiddleware=require('../middlewares/authMiddleware');
const User=require('../models/User');
const firebaseConfig=require('../config/serviceAccountKey.json');
const {googleSignIn,resetPassword,login,signup, refreshTokenHandler,requestPasswordReset,forgetPassword}=require('../controllers/authController')
FIREBASE_API_KEY=firebaseConfig.api_key;

const router=express.Router();

router.post('/google-signin', googleSignIn);
router.post('/reset-password', resetPassword);

router.post('/login',login);
router.post('/signup',signup);

router.post('/refresh-token',refreshTokenHandler);

router.post('/request-password-reset', requestPasswordReset);
router.post('/reset-password', forgetPassword);

module.exports=router;