// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const admin = require('./config/firebaseConfig'); // Import your Firebase configuration
const serviceAccount = require('./config/serviceAccountKey.json'); // Load service account key
const mongoose=require('mongoose');
const authRoutes=require('./routes/authRoutes')
const authMiddleware=require('./middlewares/authMiddleware')

const axios=require('axios')
const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/BikeStore', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(bodyParser.json());
app.use(cors());

const FIREBASE_API_KEY = serviceAccount.api_key;

app.use('/auth', authRoutes);

app.use('/protected', authMiddleware, (req, res) => {
  res.send('This is a protected route');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
