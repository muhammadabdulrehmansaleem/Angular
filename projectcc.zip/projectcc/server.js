// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const admin = require('./config/firebaseConfig'); // Import your Firebase configuration
const axios=require('axios')
const app = express();
const port = 3000;
const serviceAccount = require('./config/serviceAccountKey.json'); // Load service account key
app.use(bodyParser.json());
app.use(cors());
const FIREBASE_API_KEY = serviceAccount.api_key;
// Route for Google Sign-In
app.post('/auth/google-signin', async (req, res) => {
  const { idToken } = req.body;
  console.log(idToken)
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const user = await admin.auth().getUser(decodedToken.uid);
    console.log(user)
    res.status(200).json({ user });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Route for Password Reset
app.post('/auth/reset-password', async (req, res) => {
    const { email } = req.body;
    try {
      const response = await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${FIREBASE_API_KEY}`, {
        requestType: 'PASSWORD_RESET',
        email: email,
      });
      res.status(200).json({ message: 'Password reset email sent.', response: response.data });
    } catch (error) {
      res.status(400).json({ error: error.response.data.error.message });
    }
  });

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
