const { registerVersion } = require('firebase/app');
const User=require('../models/User')
const {generateToken,generateRefreshToken, verifyRefreshToken}=require('../utils/tokenUtils')

async function signup(email,password,name)
{
    try{
        const existingUser=await User.findOne({email});
        if(existingUser){
            throw new Error('User already exists');
        }

        const newUser=new User({email,password,name});
        await newUser.save();

        const accessToken=generateToken(newUser);
        const refreshToken=generateRefreshToken(newUser);

        return{
            user:newUser,
            accessToken,
            refreshToken
        };
    }
    catch(error){
        throw error;
    }
}
async function login(email,password)
{
    try{
        const user =await User.findOne({email});
        if(!user){
            throw new Error('User Not fund');
        }

        const isMatched=await user.comparePassword(password);
        if(!isMatched){
            throw new Error('Invalid Credentials');
        }

        const accessToken=generateToken(user);
        const refreshToken=generateRefreshToken(user);

        return {accessToken,refreshToken};
    }catch(error){
        throw error;
    }
}
async function getAccessToken(refreshToken){
    try{
        const decoded=verifyRefreshToken(refreshToken);
        const user= await User.findOne({_id: decoded.id});
        if(!user)
        {
            throw new Error('User not found');
        }

        const accessToken=generateToken(user);

        return{accessToken};
    }catch(error){
        throw error;
    }
}
module.exports={
    signup: signup,
    login:login,
    getAccessToken:getAccessToken,
};