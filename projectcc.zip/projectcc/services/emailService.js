require('dotenv').config();
const nodemailer=require('nodemailer');

const transporter=nodemailer.createTransport({
    service:'Gmail',
    auth:{
        user:process.env.EMAIL_USER,
        pass:process.env.EMAIL_PASS
    }
});

const sendResetPasswordEmail=async (email,resetToken)=>{
    const resetURL=`http://localhost:3000/reset-password?token=${resetToken}`;
    const mailOptions={
        from:'abdulrehmansaleem1051@gmail.com',
        to:email,
        subject:'Password Reset',
        text:`You are receiving this email because you (or someone else) has requested to reset your password. Please make a PUT request to the following URL to reset your password: ${resetURL}`
    };
    await transporter.sendMail(mailOptions);
};
module.exports={
    sendResetPasswordEmail:sendResetPasswordEmail

};