require('dotenv').config();
const jwt=require('jsonwebtoken')

const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;
const REFRESH_SECRET_KEY = process.env.REFRESH_SECRET_KEY;

const JWT_EXPIRES_IN = '1h'; 
const JWT_REFRESH_EXPIRES_IN = '7d';

function generateToken(user) 
{
    return jwt.sign({ id: user._id }, JWT_SECRET_KEY, { expiresIn: JWT_EXPIRES_IN });
}

function generateRefreshToken(user)
{
    return jwt.sign({ id: user._id }, REFRESH_SECRET_KEY, { expiresIn: JWT_REFRESH_EXPIRES_IN });
}

function verifyToken(token)
{
    return jwt.verify(token, JWT_SECRET);
}

function verifyRefreshToken(token) {
    return jwt.verify(token, REFRESH_SECRET_KEY);
}

module.exports = {
    generateToken,
    generateRefreshToken,
    verifyToken,
    verifyRefreshToken
  };